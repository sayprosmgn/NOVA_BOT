import subprocess
import sys

def run_bot(path):
    return subprocess.Popen([sys.executable, path])

if __name__ == "__main__":
    # Запускаем оба бота параллельно
    bot1 = run_bot("main_news_bot/bot.py")
    bot2 = run_bot("promo_bot/bot.py")

    print("Оба бота запущены. Для остановки нажмите Ctrl+C.")

    try:
        bot1.wait()
        bot2.wait()
    except KeyboardInterrupt:
        print("\nОстановка ботов...")
        bot1.terminate()
        bot2.terminate()
